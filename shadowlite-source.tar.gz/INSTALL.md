Building Shadowlite
=============

See doc/build-*.md for instructions on building the various
elements of the Shadowlite Core reference implementation of Shadowlite.
